from setuptools import setup, find_packages
from os.path import join, dirname

setup(
    name='yaml_parser',
    version='1.0',
    packages=find_packages(),
)
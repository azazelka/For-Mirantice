import unittest
from random import randint

import yaml

import tasks.yaml_parser
from tests import structure_generator
from tests.cycle_decorator import cycle_decorator


class TestYmlParser(unittest.TestCase):
    def test_list_first(self):
        result = tasks.yaml_parser.st_parser('../tests/file2.yml')
        self.assertEqual(tasks.yaml_parser.yml_parser('../tests/file2.yml'), result)

    def test_dict_first(self):
        result = tasks.yaml_parser.st_parser('../tests/file3.yml')
        self.assertEqual(tasks.yaml_parser.yml_parser('../tests/file3.yml'), result)

    def test_dict_first2(self):
        result = tasks.yaml_parser.st_parser('../tests/file1.yml')
        self.assertEqual(tasks.yaml_parser.yml_parser('../tests/file1.yml'), result)

    def test_dict_is_list_element(self):
        result = tasks.yaml_parser.st_parser('../tests/file4.yml')
        self.assertEqual(tasks.yaml_parser.yml_parser('../tests/file4.yml'), result)

    def test_yml_dump_list_is_dict_element(self):
        result = tasks.yaml_parser.st_parser('../tests/file5.yml')
        self.assertEqual(tasks.yaml_parser.yml_parser('../tests/file5.yml'), result)

    def test_yml_dump_list_is_list_element(self):
        result = tasks.yaml_parser.st_parser('../tests/file6.yml')
        self.assertEqual(tasks.yaml_parser.yml_parser('../tests/file6.yml'), result)

    @cycle_decorator(500)
    def test_stress(self):
        depth = randint(1, 4)
        size = randint(1, 5)
        seed = randint(0, 9999999999)


        structure = structure_generator.StructureGenerator(size, depth, seed).structure
        result = yaml.dump(structure, default_flow_style=False)
        #
        # print result
        # res = result.split('\n')
        print depth, size, seed
        with open("../tests/res.yml", 'w')as fd:
            fd.write(result)
        self.assertEqual(tasks.yaml_parser.yml_parser("../tests/res.yml"), structure)


if __name__ == '__main__':
    unittest.main()
